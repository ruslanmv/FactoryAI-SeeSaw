#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Define variables
APP_NAME="ecommerce-app"
DEPLOY_DIR="/var/www/$APP_NAME"
REPO_URL="https://github.com/yourusername/$APP_NAME.git"
BRANCH="main"

# Pull the latest code
if [ -d "$DEPLOY_DIR" ]; then
    cd $DEPLOY_DIR
    git pull origin $BRANCH
else
    git clone $REPO_URL $DEPLOY_DIR
    cd $DEPLOY_DIR
    git checkout $BRANCH
fi

# Install dependencies
npm install

# Build the application
npm run build

# Restart services
sudo systemctl restart nginx
sudo systemctl restart $APP_NAME