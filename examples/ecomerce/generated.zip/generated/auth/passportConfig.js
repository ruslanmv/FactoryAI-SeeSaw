const passport = require('passport');
const { Strategy: JwtStrategy, ExtractJwt } = require('passport-jwt');

const options = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: process.env.JWT_SECRET,
};

passport.use(new JwtStrategy(options, (jwtPayload, done) => {
  try {
    // Logic to find user by payload details
    const user = getUserFromPayload(jwtPayload);
    if (user) {
      return done(null, user);
    } else {
      return done(null, false);
    }
  } catch (error) {
    return done(error, false);
  }
}));

function getUserFromPayload(jwtPayload) {
  // Placeholder function to simulate user retrieval
  // Replace with actual database query in real application
  return { id: jwtPayload.id, username: jwtPayload.username };
}

module.exports = passport;