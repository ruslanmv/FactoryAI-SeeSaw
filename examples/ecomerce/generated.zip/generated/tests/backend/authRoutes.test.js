import request from 'supertest';
import app from '../../server';

describe('Auth Routes', () => {
  describe('POST /api/auth/register', () => {
    it('should register a user and return status 201', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'testuser',
          email: 'testuser@example.com',
          password: 'Password123'
        });
      expect(response.statusCode).toBe(201);
      expect(response.body).toHaveProperty('token');
    });

    it('should return 400 if username is already taken', async () => {
      await request(app)
        .post('/api/auth/register')
        .send({
          username: 'duplicateuser',
          email: 'duplicate@example.com',
          password: 'Password123'
        });

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'duplicateuser',
          email: 'another@example.com',
          password: 'Password123'
        });

      expect(response.statusCode).toBe(400);
    });
  });

  describe('POST /api/auth/login', () => {
    it('should login a user and return a token', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          username: 'existinguser',
          password: 'Password123'
        });
      expect(response.statusCode).toBe(200);
      expect(response.body).toHaveProperty('token');
    });

    it('should return 401 for invalid credentials', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          username: 'nonexistent',
          password: 'Password123'
        });
      expect(response.statusCode).toBe(401);
    });
  });

  describe('GET /api/auth/logout', () => {
    it('should logout the user and end the session', async () => {
      const response = await request(app).get('/api/auth/logout');
      expect(response.statusCode).toBe(200);
    });
  });
});