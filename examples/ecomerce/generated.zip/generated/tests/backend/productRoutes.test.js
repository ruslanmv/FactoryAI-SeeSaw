const request = require('supertest');
const app = require('../../app');
const { Product } = require('../../models');

describe('Product API', () => {
  beforeAll(async () => {
    // Seed the database with some initial products
    await Product.create({ name: 'Test Product 1', description: 'First Test Product', price: 50 });
    await Product.create({ name: 'Test Product 2', description: 'Second Test Product', price: 75 });
  });

  afterAll(async () => {
    await Product.deleteMany({});
  });

  test('GET /api/products - should return all products', async () => {
    const res = await request(app).get('/api/products');
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveLength(2);
  });

  test('GET /api/products/:id - should return a specific product by id', async () => {
    const product = await Product.findOne({ name: 'Test Product 1' });
    const res = await request(app).get(`/api/products/${product._id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.name).toBe('Test Product 1');
  });

  test('POST /api/products - should create a new product', async () => {
    const newProduct = { name: 'Test Product 3', description: 'Third Test Product', price: 60 };
    const res = await request(app).post('/api/products').send(newProduct);
    expect(res.statusCode).toBe(201);
    expect(res.body.name).toBe('Test Product 3');
  });

  test('PUT /api/products/:id - should update an existing product', async () => {
    const product = await Product.findOne({ name: 'Test Product 1' });
    const updateData = { price: 55 };
    const res = await request(app).put(`/api/products/${product._id}`).send(updateData);
    expect(res.statusCode).toBe(200);
    expect(res.body.price).toBe(55);
  });

  test('DELETE /api/products/:id - should delete a product', async () => {
    const product = await Product.findOne({ name: 'Test Product 2' });
    const res = await request(app).delete(`/api/products/${product._id}`);
    expect(res.statusCode).toBe(200);
    const deletedProduct = await Product.findById(product._id);
    expect(deletedProduct).toBeNull();
  });
});