import React, { useState } from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import MainComponent from './MainComponent';
import ProductDetail from './ProductDetail';
import Cart from './Cart';

jest.mock('./ProductDetail', () => (props) => (
  <div>
    {props.product ? <><div>{props.product.name}</div><div>{props.product.description}</div><div>Price: ${props.product.price.toFixed(2)}</div><button onClick={props.addToCartHandler}>Add to Cart</button></> : 'No product available'}
  </div>
));

jest.mock('./Cart', () => ({ cartItems }) => (
  <div>
    {cartItems.length > 0
      ? <><div>{cartItems[0].name}</div><div>Total Price: ${(cartItems[0].price * cartItems[0].quantity).toFixed(2)}</div></>
      : 'Your cart is empty'}
    <button>Checkout</button>
  </div>
));

const MainComponent = () => {
  const [clicked, setClicked] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const sampleProduct = {
    name: 'Test Product',
    description: 'This is a test product.',
    price: 99.99
  };
  
  const handleButtonClick = () => setClicked(true);
  
  const handleAddToCart = () => {
    setCartItems([{ ...sampleProduct, quantity: 1 }]);
  };

  return (
    <div>
      <div>Main Component</div>
      <button onClick={handleButtonClick}>Click Me</button>
      {clicked && <div>Button clicked</div>}
      <ProductDetail product={sampleProduct} addToCartHandler={handleAddToCart} />
      <Cart cartItems={cartItems} />
      <div data-testid="footer-component">Footer</div>
    </div>
  );
};

describe('MainComponent', () => {
  test('renders without crashing', () => {
    const { container } = render(<MainComponent />);
    expect(container).toBeInTheDocument();
  });

  test('checks button click functionality', () => {
    render(<MainComponent />);
    const buttonElement = screen.getByRole('button', { name: /Click Me/i });
    expect(buttonElement).toBeEnabled();
    fireEvent.click(buttonElement);
    expect(screen.getByText(/Button clicked/i)).toBeInTheDocument();
  });

  test('ensures proper rendering of child component', () => {
    render(<MainComponent />);
    expect(screen.getByText(/No product available/i)).toBeInTheDocument();
  });

  test('renders the footer component', () => {
    render(<MainComponent />);
    expect(screen.getByTestId('footer-component')).toBeInTheDocument();
  });
});

describe('ProductDetail', () => {
  test('renders "No product available" when no product is passed', () => {
    render(<ProductDetail />);
    expect(screen.getByText('No product available')).toBeInTheDocument();
  });

  test('renders product details correctly', () => {
    const product = {
      name: 'Test Product',
      description: 'This is a test product.',
      price: 99.99
    };
    render(<ProductDetail product={product} />);
    expect(screen.getByText('Test Product')).toBeInTheDocument();
    expect(screen.getByText('This is a test product.')).toBeInTheDocument();
    expect(screen.getByText('Price: $99.99')).toBeInTheDocument();
  });

  test('checks Add to Cart button functionality', () => {
    const product = {
      name: 'Test Product',
      description: 'This is a test product.',
      price: 99.99
    };
    render(<ProductDetail product={product} addToCartHandler={jest.fn()} />);
    const buttonElement = screen.getByRole('button', { name: /Add to Cart/i });
    expect(buttonElement).toBeEnabled();
    fireEvent.click(buttonElement);
    expect(screen.getByText(/Added to cart/i)).toBeInTheDocument();
  });
});

describe('Cart', () => {
  test('renders empty cart message', () => {
    render(<Cart cartItems={[]} />);
    expect(screen.getByText('Your cart is empty')).toBeInTheDocument();
  });

  test('renders cart items and total price', () => {
    const cartItems = [{ id: 1, name: 'Product 1', price: 50, quantity: 2 }];
    render(<Cart cartItems={cartItems} />);
    expect(screen.getByText('Product 1')).toBeInTheDocument();
    expect(screen.getByText('Total Price: $100.00')).toBeInTheDocument();
  });

  test('checks checkout button state', () => {
    const cartItems = [{ id: 1, name: 'Product 1', price: 50, quantity: 2 }];
    render(<Cart cartItems={cartItems} />);
    expect(screen.getByRole('button', { name: /Checkout/i })).toBeEnabled();
  });
});