const express = require('express');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Mock data
const products = [
  { id: 1, name: 'Test Product 1', description: 'Description 1', price: 99.99 },
  { id: 2, name: 'Test Product 2', description: 'Description 2', price: 59.99 }
];

// Routes
app.get('/products', (req, res) => {
  res.json(products);
});

app.post('/cart', (req, res) => {
  const { productId } = req.body;
  // Logic for adding to cart
  res.json({ message: 'Product added to cart', productId });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});