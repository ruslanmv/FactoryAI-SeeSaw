import React from 'react';

const Footer = () => {
  return (
    <footer data-testid="footer-component">
      <p>&copy; 2023 MyCompany. All rights reserved.</p>
    </footer>
  );
};

export default Footer;