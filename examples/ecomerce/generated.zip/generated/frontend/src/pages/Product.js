import React from 'react';

const ProductDetail = ({ product }) => {
  if (!product) {
    return <div data-testid="no-product">No product available</div>;
  }

  return (
    <div data-testid="product-detail">
      <h1>{product.name}</h1>
      <p>{product.description}</p>
      <p>Price: ${product.price}</p>
      <button data-testid="add-to-cart" onClick={() => alert('Product added to cart')}>
        Add to Cart
      </button>
    </div>
  );
};

export default ProductDetail;