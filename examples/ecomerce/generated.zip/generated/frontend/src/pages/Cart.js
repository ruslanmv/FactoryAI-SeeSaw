import React from 'react';
import CartItem from './CartItem';

const Cart = ({ cartItems, onRemove }) => {
  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <div data-testid="cart-page">
      <h2>Shopping Cart</h2>
      {cartItems.length === 0 ? (
        <p data-testid="empty-cart">Your cart is empty</p>
      ) : (
        <div data-testid="cart-items">
          {cartItems.map(item => (
            <CartItem key={item.id} item={item} onRemove={onRemove} />
          ))}
          <div data-testid="total-price">Total Price: ${getTotalPrice().toFixed(2)}</div>
        </div>
      )}
      <button disabled={cartItems.length === 0} data-testid="checkout-button">
        Proceed to Checkout
      </button>
    </div>
  );
};

export default Cart;