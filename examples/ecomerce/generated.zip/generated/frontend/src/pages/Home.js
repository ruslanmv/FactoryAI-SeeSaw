import React from 'react';

const Home = () => {
  return (
    <div data-testid="home-page">
      <header>
        <h1>Welcome to Our E-commerce Platform</h1>
      </header>
      <main>
        <section>
          <h2>Featured Products</h2>
          {/* Placeholder for featured products */}
        </section>
        <section>
          <h2>Latest News</h2>
          {/* Placeholder for latest news */}
        </section>
      </main>
      <footer>
        <div data-testid="home-footer">
          <p>© 2023 E-commerce Platform</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;