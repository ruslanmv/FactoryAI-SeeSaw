import React from 'react';
import MainComponent from './MainComponent';

function App() {
  return (
    <div data-testid="app">
      <MainComponent />
    </div>
  );
}

export default App;